#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gimp, gimpplugin, math, array, sys
from gimpenums import *

pdb = gimp.pdb
import gtk, gimpui, gimpcolor
from gimpshelf import shelf

corners = [[-1, -1], [-1, 0], [-1, 1],
           [0, -1], [0, 0], [0, 1],
           [1, -1], [1, 0], [1, 1]]
# Different types of kernels
sobel_x = [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]
sobel_y = [[1, 2, 1], [0, 0, 0], [-1, -2, -1]]

prewitt_x = [[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]]
prewitt_y = [[1, 1, 1], [0, 0, 0], [-1, -1, -1]]

robinson_x = [[-1, -1, -1], [1, -2, 1], [1, 1, 1]]
robinson_y = [[-1, 1, 1], [-1, -2, 1], [-1, 1, 1]]

kirsch_x = [[-5, -5, -5], [3, 0, 3], [3, 3, 3]]
kirsch_y = [[-5, 3, 3], [-5, 0, 3], [-5, 3, 3]]


class convolution_plugin(gimpplugin.plugin):

    def start(self):
        gimp.main(self.init, self.quit, self.query, self._run)

    def init(self):
        pass

    def quit(self):
        pass

    def query(self):
        gimp.install_procedure(
            "convolution_plugin_main",
            "Detects edges",
            "This plugin detects vertical or horizontal edges in an image",
            "Michael Moyal",
            "Michael Moyal",
            "2021",
            "<Image>/Filters/Edge Detection (moyalmic)",
            "RGB*, GRAY*",
            PLUGIN,
            [
                # next three parameters are common for all scripts that are inherited from gimpplugin.plugin
                (PDB_INT32, "run_mode", "Run mode"),
                (PDB_IMAGE, "image", "Input image"),
                (PDB_DRAWABLE, "drawable", "Input drawable"),
                (PDB_INT32, "kernel", "Kernel")
            ],
            []
        )

    def convolution_plugin_main(self, run_mode, image, drawable):
        self.image = image
        self.drawable = drawable
        self.shelfkey = "edge_detect_moyal"
        # Create UI to ask the user which type of edge detection to do
        self.create_dialog()
        # Storage
        if not shelf.has_key(self.shelfkey):
            self.create_storage()

        pdb.gimp_image_undo_group_start(self.image)
        # If ran non interactively, 0 will be the default
        if run_mode == RUN_INTERACTIVE:
            self.dialog.run()
        else:
            self.operator = shelf[self.shelfkey]["kernel"]

        pdb.gimp_image_undo_group_end(self.image)
        gimp.displays_flush()

    def create_dialog(self):
        self.dialog = gimpui.Dialog("Edge Detect", "edge_detect_dialog")

        # create table
        self.table = gtk.Table(3, 6, False)
        self.table.set_row_spacings(10)
        self.table.set_col_spacings(10)
        self.table.show()

        # initialize container that holds everything together
        self.dialog.vbox.hbox = gtk.HBox(True, 0)
        self.dialog.vbox.hbox.show()
        self.dialog.vbox.pack_start(self.dialog.vbox.hbox, False, False, 0)
        self.dialog.vbox.hbox.pack_start(self.table, True, True, 0)

        # add sentence to guide a user
        self.label = gtk.Label("Choose operator for edge detection:")
        self.label.set_line_wrap(True)
        self.label.set_alignment(0, 0.5)
        self.label.show()
        self.table.attach(self.label, 1, 2, 0, 1)

        # create a list of items to choose from
        self.multi_choice = gtk.combo_box_new_text()
        self.multi_choice.append_text("Prewitt")
        self.multi_choice.append_text("Sobel")
        self.multi_choice.append_text("Robinson")
        self.multi_choice.append_text("Kirsch")

        # respond to user's choice
        self.multi_choice.connect("changed", self.change_kernel)
        self.multi_choice.set_entry_text_column(0)
        self.multi_choice.set_active(0)
        self.multi_choice.show()
        self.table.attach(self.multi_choice, 1, 2, 2, 3)

        # create ok and cancel buttons
        self.ok_button = self.dialog.add_button(gtk.STOCK_OK, gtk.RESPONSE_OK)
        self.cancel_button = self.dialog.add_button(gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL)

        self.ok_button.connect("clicked", self.ok_clicked)
        self.cancel_button.connect("clicked", self.cancel_clicked)

        # show dialog
        self.dialog.show()

    def ok_clicked(self, widget):
        self.set_kernel()
        self.process_image()

    def cancel_clicked(self, widget):
        self.quit()

    def change_kernel(self, multi_choice):
        self.operator = multi_choice.get_active()
        return self.operator

    def set_kernel(self):
        if self.operator == 0:
            self.kernelX = prewitt_x
            self.kernelY = prewitt_y
        elif self.operator == 1:
            self.kernelX = sobel_x
            self.kernelY = sobel_y
        elif self.operator == 2:
            self.kernelX = robinson_x
            self.kernelY = robinson_y
        elif self.operator == 3:
            self.kernelX = kirsch_x
            self.kernelY = kirsch_y

        shelf[self.shelfkey] = {
            "kernel": self.operator
        }

    def process_image(self):
        self.bpp = self.drawable.bpp
        tl_X, tl_Y, br_X, br_Y = self.drawable.mask_bounds
        self.width = abs(tl_X - br_X)
        self.height = abs(tl_Y - br_Y)

        source_region = self.drawable.get_pixel_rgn(tl_X, tl_Y, self.width, self.height, False, False)
        self.source_pixels = array.array("B", source_region[tl_X:br_X, tl_Y:br_Y])

        newLayer = gimp.Layer(self.image, "Edge Detect", self.width, self.height, RGB_IMAGE, 100, NORMAL_MODE)

        destination_region = newLayer.get_pixel_rgn(0, 0, self.width, self.height, True, True)
        self.destination_pixels = array.array("B", destination_region[0:self.width, 0:self.height])

        self.image.add_layer(newLayer, 0)
        gimp.progress_init('Detecting edges...')
        for row in range(0, self.height):
            for col in range(0, self.width):
                # moves me row lines down, col indexes and also need to multiply bits per pixel
                current_pixel = (row * self.width + col) * self.bpp
                pixel_data = self.source_pixels[current_pixel:current_pixel + self.bpp]
                neighbour_matrix = self.get_neighbour_matrix(col, row)
                pixel_edge_magnitude_x = self.get_pixel_edge_magnitude(neighbour_matrix, self.kernelX) * 0.5
                pixel_edge_magnitude_y = self.get_pixel_edge_magnitude(neighbour_matrix, self.kernelY) * 0.5
                pixel_edge_magnitude = math.sqrt(pow(pixel_edge_magnitude_x, 2) + pow(pixel_edge_magnitude_y, 2))
                pixel_edge_magnitude = min(pixel_edge_magnitude, 255)
                pixel_edge_magnitude = max(pixel_edge_magnitude, 0)
                for i in range(0, self.bpp):
                    pixel_edge_magnitude = min(pixel_edge_magnitude, 255)
                    pixel_edge_magnitude = max(pixel_edge_magnitude, 0)
                    pixel_data[i] = int(pixel_edge_magnitude)
                self.destination_pixels[current_pixel:current_pixel + self.bpp] = pixel_data
            gimp.progress_update(float(row + 1) / self.height)
        destination_region[0:self.width, 0:self.height] = self.destination_pixels.tostring()
        newLayer.flush()
        newLayer.merge_shadow(True)
        newLayer.update(0, 0, self.width, self.height)

    def create_storage(self):
        shelf[self.shelfkey] = {
            "kernel": 0
        }

    def get_pixel_edge_magnitude(self, pixel_neighbours, kernel):
        accumulator = 0
        for i in range(0, 3):
            for j in range(0, 3):
                temp = pixel_neighbours[i][j] * kernel[i][j]
                accumulator += temp
        accumulator = min(accumulator, 255)
        accumulator = max(accumulator, 0)
        return accumulator

    def get_neighbour_matrix(self, col, row):
        neighbour_matrix = list()
        for offset in corners:
            nrow = row + offset[0]
            ncol = col + offset[1]
            position = 0
            # pixel is in bounds of image
            if nrow >= 0 and nrow < self.height and ncol >= 0 and ncol < self.width:
                position = (nrow * self.width + ncol) * self.bpp
                pixel_to_insert = greyscale_pixel(self.source_pixels[position:position + self.bpp])
                neighbour_matrix.append(pixel_to_insert)
            # This happens when the pixel is beyond the bounds of the image
            else:
                neighbour_matrix.append(0)
        return [neighbour_matrix[0:3], neighbour_matrix[3:6], neighbour_matrix[6:9]]


def greyscale_pixel(pixel):
    return (0.299 * pixel[0]) + (0.587 * pixel[1]) + (0.114 * pixel[2])


if __name__ == '__main__':
    convolution_plugin().start()
